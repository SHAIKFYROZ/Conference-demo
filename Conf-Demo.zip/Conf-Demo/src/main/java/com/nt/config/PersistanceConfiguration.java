package com.nt.config;

import javax.sql.DataSource;

import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PersistanceConfiguration {
//	@Bean
//	public DataSource datasource() {
//		DataSourceBuilder builder= DataSourceBuilder.create();
//		builder.url("jdbc:postgresql://localhost:5432/postgres");
//		System.out.println("My Custom DataSource Bean is intilitized and set");
//		return builder.build();
		
	//}

}
