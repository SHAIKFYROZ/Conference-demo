package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ConfDemoApplication {

	public static void main(String[] args) {
		System.out.println("Started");
		SpringApplication.run(ConfDemoApplication.class, args);
		System.out.println("Stoped");
	}

}
