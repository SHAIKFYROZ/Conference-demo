package com.nt.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nt.model.Session;

public interface SessionRepository extends JpaRepository<Session, Long>{
	

}
