package com.nt.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nt.model.Speaker;

public interface SpeakerRepository extends JpaRepository<Speaker, Long>{
	

}
